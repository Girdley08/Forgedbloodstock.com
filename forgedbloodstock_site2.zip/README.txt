Upload index.html + assets folder to repo root.
