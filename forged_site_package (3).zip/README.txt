Forged Bloodstock Intelligence — One‑Page Site

How to use
1) Upload `index.html` and the `assets` folder to your host (GitHub Pages/Neocities/etc.).
2) Replace `FORM_ID` in the contact form action with your Formspree ID.
3) Done. Your logo is `assets/logo.svg` and the favicon is `assets/favicon.png`.

Brand colors
- Charcoal #2D2B2B
- Gold #8B5E3C
- Cream #EFE9D5

Built for Chris Girdley.
